// vlh.v and vlseg[2-8]hff.v
VI_LDST_FF(int, 16);
