// vasubu.vx vd, vs2, rs1
VI_VVX_ULOOP_AVG(rs1, -, false);
