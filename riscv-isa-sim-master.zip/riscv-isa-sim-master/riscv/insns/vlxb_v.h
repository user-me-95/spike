// vlxb.v and vlsseg[2-8]b.v
require(P.VU.vsew >= e8);
VI_DUPLICATE_VREG(insn.rs2(), P.VU.vlmax);
VI_LD_INDEX(index[i], fn, int8, 1);
