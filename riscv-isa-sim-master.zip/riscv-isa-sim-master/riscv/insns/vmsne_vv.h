// vneq.vv  vd, vs2, vs1
VI_VV_LOOP_CMP
({
  res = vs2 != vs1;
})
