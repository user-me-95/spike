// vlwff.v
// vlw.v and vlseg[2-8]wff.v
VI_LDST_FF(int, 32);
