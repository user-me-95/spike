// vlhu.v and vlseg[2-8]hu.v
require(P.VU.vsew >= e16);
VI_LD(0, i * nf + fn, uint16, 2);
