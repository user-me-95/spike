require_extension('Q');
require_fp;
WRITE_FRD(fsgnj128(FRS1, FRS2, false, false));
