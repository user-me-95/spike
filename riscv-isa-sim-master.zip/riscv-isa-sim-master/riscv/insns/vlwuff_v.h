// vlwuff.v and vlseg[2-8]wuff.v
VI_LDST_FF(uint, 32);
