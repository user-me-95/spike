// vlsw.v and vlsseg[2-8]w.v
require(P.VU.vsew >= e32);
VI_LD(i * RS2, fn, int32, 4);
