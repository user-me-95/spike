WRITE_RD(RS1 < reg_t(insn.i_imm()));
