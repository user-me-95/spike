require_extension('C');
WRITE_RD(insn.rvc_imm());
