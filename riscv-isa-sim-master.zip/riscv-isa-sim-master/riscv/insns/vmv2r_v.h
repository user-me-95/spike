// vmv2r.v vd, vs2
#include "vmvnfr_v.h"
