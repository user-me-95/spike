// vlwu.v and vlseg[2-8]wu.v
require(P.VU.vsew >= e32);
VI_LD(0, i * nf + fn, uint32, 4);
