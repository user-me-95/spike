// vlw.v and vlseg[2-8]w.v
require(P.VU.vsew >= e32);
VI_LD(0, i * nf + fn, int32, 4);
