// vlb.v and vlseg[2-8]b.v
require(P.VU.vsew >= e8);
VI_LD(0, i * nf + fn, int8, 1);
