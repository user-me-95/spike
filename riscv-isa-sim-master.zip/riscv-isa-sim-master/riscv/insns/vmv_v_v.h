// vvmv.v.v vd, vs1
require_vector;
VI_CHECK_SSS(true);
VI_VVXI_MERGE_LOOP
({
  vd = vs1;
})
