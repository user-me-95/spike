// vmnor.mm vd, vs2, vs1
VI_LOOP_MASK(~(vs2 | vs1));
