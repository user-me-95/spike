// vlhuff.v and vlseg[2-8]huff.v
VI_LDST_FF(uint, 16);
