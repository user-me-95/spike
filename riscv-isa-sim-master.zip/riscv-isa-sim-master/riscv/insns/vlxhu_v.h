// vlxh.v and vlxseg[2-8]h.v
require(P.VU.vsew >= e16);
VI_DUPLICATE_VREG(insn.rs2(), P.VU.vlmax);
VI_LD_INDEX(index[i], fn, uint16, 2);
