// vlsh.v and vlsseg[2-8]h.v
require(P.VU.vsew >= e16);
VI_LD(i * RS2, fn, uint16, 2);
