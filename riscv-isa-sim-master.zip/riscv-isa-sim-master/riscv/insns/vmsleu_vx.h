// vsleu.vx  vd, vs2, rs1
VI_VX_ULOOP_CMP
({
  res = vs2 <= rs1;
})
