// vlbuff.v and vlseg[2-8]buff.v
VI_LDST_FF(uint, 8);
