// vsgt.vi  vd, vs2, simm5
VI_VI_LOOP_CMP
({
  res = vs2 > simm5;
})
