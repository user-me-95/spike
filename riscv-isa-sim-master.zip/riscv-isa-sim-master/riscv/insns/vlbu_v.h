// vlbu.v and vlseg[2-8]bu.v
require(P.VU.vsew >= e8);
VI_LD(0, i * nf + fn, uint8, 1);
