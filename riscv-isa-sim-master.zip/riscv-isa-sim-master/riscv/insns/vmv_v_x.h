// vmv.v.x vd, rs1
require_vector;
VI_CHECK_SSS(false);
VI_VVXI_MERGE_LOOP
({
  vd = rs1;
})
