// vlsb.v and vlsseg[2-8]b.v
require(P.VU.vsew >= e8);
VI_LD(i * RS2, fn, uint8, 1);
