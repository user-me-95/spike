// vlbff.v and vlseg[2-8]bff.v
VI_LDST_FF(int, 8);
