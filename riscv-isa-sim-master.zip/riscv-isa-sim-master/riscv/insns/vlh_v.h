// vlh.v and vlseg[2-8]h.v
require(P.VU.vsew >= e16);
VI_LD(0, i * nf + fn, int16, 2);
