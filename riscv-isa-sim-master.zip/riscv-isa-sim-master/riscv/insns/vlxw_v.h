// vlxw.v and vlxseg[2-8]w.v
require(P.VU.vsew >= e32);
VI_DUPLICATE_VREG(insn.rs2(), P.VU.vlmax);
VI_LD_INDEX(index[i], fn, int32, 4);
