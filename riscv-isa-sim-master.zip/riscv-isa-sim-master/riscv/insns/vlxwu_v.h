// vlxwu.v and vlxseg[2-8]wu.v
require(P.VU.vsew >= e32);
VI_DUPLICATE_VREG(insn.rs2(), P.VU.vlmax);
VI_LD_INDEX(index[i], fn, uint32, 4);
